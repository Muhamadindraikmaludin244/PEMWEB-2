<?php
require_once 'header.php';
require_once 'sidebar.php';
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    </section>

    <!-- Main content -->
    <section class="content">

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Default box -->
                    <div class="card">
                        <div class="card-header">
                            <h2>Form Dokter Puskesmas</h2>
                        </div>
                        <!-- /.card-header -->
                        <div class= "Container">
                        </div>
                        <div class="card-body">
<form method="POST" action="proses_dokter.php" class="m-4">
  <div class="form-group row">
    <label for="nama" class="col-4 col-form-label">Nama Lengkap</label> 
    <div class="col-8">
      <input id="nama" name="nama" type="text" class="form-control" placeholder="Tuliskan nama lengkap beserta gelar" required="required" >
    </div>
  </div>
  <div class="form-group row">
    <label for="gender" class="col-4">Jenis Kelamin</label> 
    <div class="col-8">
      <div class="custom-control custom-radio custom-control-inline">
      <input name="gender" id="radio_0" type="radio" class="custom-control-input" value="Laki" required="required"> 
        <label for="radio_0" class="custom-control-label">Laki-Laki</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="gender" id="radio_1" type="radio" class="custom-control-input" value="Perempuan" required="required">
        <label for="radio_1" class="custom-control-label">Perempuan</label>
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="tmp_lahir" class="col-4 col-form-label">Tempat Lahir</label> 
    <div class="col-8">
      <input id="tmp_lahir" name="tmp_lahir" type="text" class="form-control" required="required">
    </div>
  </div>
  <div class="form-group row">
    <label for="tgl_lahir" class="col-4 col-form-label">Tanggal Lahir</label> 
    <div class="col-8">
      <input id="tgl_lahir" name="tgl_lahir" type="date" class="form-control" required="required">
    </div>
  </div>
  <div class="form-group row">
    <label for="telepon" class="col-4 col-form-label">Telepon</label> 
    <div class="col-8">
      <input id="telepon" name="telepon" type="tel" class="form-control" required="required">
    </div>
  </div>
  <div class="form-group row">
    <label for="alamat" class="col-4 col-form-label">Alamat</label> 
    <div class="col-8">
      <textarea id="alamat" name="alamat" cols="40" rows="5" class="form-control" required="required"></textarea>
    </div>
  </div>
  <div class="form-group row">
    <label for="unit_kerja_id" class="col-4 col-form-label">Unit Kerja</label> 
    <div class="col-8">
        <select id="unit_kerja_id" name="unit_kerja_id" class="custom-select" required="required">
            <option value="1">Unit Gawat Darurat</option>
            <option value="2">Unit Pelayanan Rawat Jalan</option>
            <option value="3">Unit Kesehatan Ibu dan Anak (KIA)</option>
            <option value="4">Unit Pelayanan Kesehatan Masyarakat</option>
            <option value="5">Unit Manajemen Program Kesehatan</option>
        </select>
    </div>
  </div>
  <div class="form-group row">
        <label for="kategori" class="col-4 col-form-label">Kategori</label> 
        <div class="col-8">
        <select id="kategori" name="kategori" class="custom-select" required="required">
            <option value="Umum">Umum</option>
            <option value="Spesialis">Spesialis</option>
            <option value="Bidan">Bidan</option>
            <option value="Dokter Gigi">Dokter Gigi</option>
            <option value="Anastesi">Anastesi</option>
            <option value="Bedah">Bedah</option>
            <option value="Ginekolog">Ginekolog</option>
          </select>
        </div>
    </div>
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
</form>
</div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>
<?php
require_once 'footer.php';
?>