<?php
require_once 'dbkoneksi.php'; 
require_once 'header.php';
require_once 'sidebar.php';

// Ambil data kelurahan beserta id-nya dari database
$query_kelurahan = "SELECT id, nama FROM kelurahan"; // Mengambil nama kelurahan dan id
$kelurahans = $dbh->query($query_kelurahan);
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    </section>

    <!-- Main content -->
    <section class="content">

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Default box -->
                    <div class="card">
                        <div class="card-header">
                            <h2>Data Pasien Puskesmas</h2>
                        </div>
                        <!-- /.card-header -->
                        <div class= "Container">
                        </div>
                        <div class="card-body">
    <form method="POST" action="proses_pasien.php" class="m-4">
      <div class="form-group row">
        <label for="kode" class="col-4 col-form-label">Kode</label> 
        <div class="col-8">
          <div class="input-group">
            <div class="input-group-prepend">
              <div class="input-group-text">
                <i class="fa fa-address-card"></i>
              </div>
            </div> 
            <input id="kode" name="kode" type="number" class="form-control" required="required">
          </div>
        </div>
      </div>
      <div class="form-group row">
        <label for="nama" class="col-4 col-form-label">Nama Lengkap</label> 
        <div class="col-8">
          <input id="nama" name="nama" type="text" class="form-control" required="required">
        </div>
      </div>
      <div class="form-group row">
        <label for="tmp_lahir" class="col-4 col-form-label">Tempat Lahir</label> 
        <div class="col-8">
          <input id="tmp_lahir" name="tmp_lahir" type="text" class="form-control" required="required">
        </div>
      </div>
      <div class="form-group row">
        <label for="tgl_lahir" class="col-4 col-form-label">Tanggal Lahir</label> 
        <div class="col-8">
          <input id="tgl_lahir" name="tgl_lahir" type="date" class="form-control" required="required">
        </div>
      </div>
      <div class="form-group row">
        <label class="col-4">Jenis Kelamin</label> 
        <div class="col-8">
          <div class="custom-control custom-radio custom-control-inline">
            <input name="gender" id="radio_0" type="radio" class="custom-control-input" value="Laki" required="required"> 
            <label for="radio_0" class="custom-control-label">Laki-Laki</label>
          </div>
          <div class="custom-control custom-radio custom-control-inline">
            <input name="gender" id="radio_1" type="radio" class="custom-control-input" value="Perempuan" required="required">
            <label for="radio_1" class="custom-control-label">Perempuan</label>
          </div>
        </div>
      </div>
      <div class="form-group row">
        <label for="email" class="col-4 col-form-label">Email</label> 
        <div class="col-8">
          <input id="email" name="email" type="text" class="form-control" required="required">
        </div>
      </div>
      <div class="form-group row">
        <label for="alamat" class="col-4 col-form-label">Alamat</label> 
        <div class="col-8">
          <textarea id="alamat" name="alamat" cols="40" rows="5" class="form-control" required="required"></textarea>
        </div>
      </div>
      <div class="form-group row">
        <label for="kelurahan_id" class="col-4 col-form-label">Kelurahan</label> 
        <div class="col-8">
          <select id="kelurahan_id" name="kelurahan_id" class="form-control" required>
            <option value="">Pilih Kelurahan</option>
            <?php foreach ($kelurahans as $kelurahan): ?>
              <option value="<?php echo $kelurahan['id']; ?>"><?php echo $kelurahan['nama']; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="form-group row">
        <div class="offset-4 col-8">
          <button name="submit" type="submit" class="btn btn-primary" value="submit">Submit</button>
        </div>
      </div>
    </form>
    </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>
<?php
require_once 'footer.php';
?>
