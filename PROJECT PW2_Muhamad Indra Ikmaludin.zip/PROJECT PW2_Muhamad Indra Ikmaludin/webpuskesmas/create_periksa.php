<?php
require_once 'dbkoneksi.php'; 
require_once 'header.php';
require_once 'sidebar.php';

// Ambil data dokter dari database
$query_dokter = "SELECT id, nama FROM paramedik";
$dokters = $dbh->query($query_dokter);

// Ambil data pasien dari database
$query_pasien = "SELECT id, nama FROM pasien";
$pasiens = $dbh->query($query_pasien);
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    </section>

    <!-- Main content -->
    <section class="content">

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Default box -->
                    <div class="card">
                        <div class="card-header">
                            <h2>Form Periksa</h2>
                        </div>
                        <!-- /.card-header -->
                        <div class= "Container">
                        </div>
                        <div class="card-body">
<form method="POST" action="proses_periksa.php" class="m-4">
    <div class="form-group row">
        <label for="tanggal" class="col-4 col-form-label">Tanggal</label> 
        <div class="col-8">
        <input id="tanggal" name="tanggal" type="date" class="form-control" required="required">
        </div>
    </div>
  <div class="form-group row">
    <label for="tensi" class="col-4 col-form-label">Tensi Darah</label> 
    <div class="col-8">
      <input id="tensi" name="tensi" type="text" class="form-control" required="required">
    </div>
  </div>
  <div class="form-group row">
    <label for="keterangan" class="col-4 col-form-label">Keterangan</label> 
    <div class="col-8">
      <textarea id="keterangan" name="keterangan" cols="40" rows="5" class="form-control" required="required"></textarea>
    </div>
  </div>
  <div class="form-group row">
    <label for="berat" class="col-4 col-form-label">Berat Badan (kg)</label> 
    <div class="col-8">
      <input id="berat" name="berat" type="number" step="0.01" class="form-control" placeholder="Masukkan berat (kg)" required="required">
    </div>
  </div>
  <div class="form-group row">
    <label for="tinggi" class="col-4 col-form-label">Tinggi Badan (cm)</label> 
    <div class="col-8">
      <input id="tinggi" name="tinggi" type="number" step="0.01" class="form-control" required="required">
    </div>
  </div>
  <div class="form-group row">
    <label for="pasien_id" class="col-4 col-form-label">ID Pasien</label> 
    <div class="col-8">
        <select id="pasien_id" name="pasien_id" class="form-control" required>
            <option value="">Pilih ID Pasien</option>
            <?php foreach ($pasiens as $pasien): ?>
                <option value="<?php echo $pasien['id']; ?>"><?php echo $pasien['id'] . ' - ' . $pasien['nama']; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
  </div>
  <div class="form-group row">
      <label for="dokter_id" class="col-4 col-form-label">ID Dokter</label> 
      <div class="col-8">
          <select id="dokter_id" name="dokter_id" class="form-control" required>
              <option value="">Pilih ID Dokter</option>
              <?php foreach ($dokters as $dokter): ?>
                  <option value="<?php echo $dokter['id']; ?>"><?php echo $dokter['id'] . ' - ' . $dokter['nama']; ?></option>
              <?php endforeach; ?>
          </select>
      </div>
  </div>

    <div class="form-group row">
        <div class="offset-4 col-8">
            <button name="submit" type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>
</form>
</div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>
<?php
require_once 'footer.php';
?>