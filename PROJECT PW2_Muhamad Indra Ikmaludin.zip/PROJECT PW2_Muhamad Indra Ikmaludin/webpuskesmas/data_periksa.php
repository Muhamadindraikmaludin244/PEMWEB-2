<?php
// Include database connection
require_once 'dbkoneksi.php';

// Query to fetch data periksa
$query = "SELECT * FROM periksa";
// Execute the query using PDO:
$periksas = $dbh->query($query);
?>

<?php
require_once 'header.php';
require_once 'sidebar.php';
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    </section>

    <!-- Main content -->
    <section class="content">

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Default box -->
                    <div class="card">
                        <div class="card-header">
                            <h2>Data Periksa Puskesmas</h2>
                        </div>
                        <!-- /.card-header -->
                        <div class= "Container">
                            <a href="create_periksa.php" class= "btn btn-primary ml-3 mt-3"> Tambah Data Periksa</a>
                        </div>
                        <div class="card-body">
        <table class="table">
            <tr class="table-danger">
                <th>No</th>
                <th>Tanggal</th>
                <th>Tensi Darah</th>
                <th>Keterangan</th>
                <th>Berat</th>
                <th>Tinggi</th>
                <th>ID Pasien</th>
                <th>ID Dokter</th>
                <th>Aksi</th>
                <th></th>
            </tr>
            <?php 
            $no = 0;

            foreach ($periksas as $periksa): ?>
                <tr>
                    <td><?php echo ++$no; ?></td>
                    <td><?php echo $periksa['tanggal']; ?></td>
                    <td><?php echo $periksa['tensi']; ?></td>
                    <td><?php echo $periksa['keterangan']; ?></td>
                    <td><?php echo $periksa['berat']; ?></td>
                    <td><?php echo $periksa['tinggi']; ?></td>
                    <td><?php echo $periksa['pasien_id']; ?></td>
                    <td><?php echo $periksa['dokter_id']; ?></td>
                    <td>
                        <a href="edit_periksa.php?id=<?php echo $periksa['id']; ?>" class="btn btn-primary">Edit</a>
                        <a href="hapus_periksa.php?id=<?php echo $periksa['id']; ?>" class="btn btn-danger">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"></script>

<?php
require_once 'footer.php';
?>
