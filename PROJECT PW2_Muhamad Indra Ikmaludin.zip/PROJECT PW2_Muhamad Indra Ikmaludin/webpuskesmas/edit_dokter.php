<?php
require_once 'dbkoneksi.php';
require_once 'header.php';
require_once 'sidebar.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    // Query untuk mengambil data dokter berdasarkan id
    $sql = "SELECT * FROM paramedik WHERE id = ?";
    $stmt = $dbh->prepare($sql);
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    // Inisialisasi variabel dengan data dari database
    $nama = $row['nama'];
    $gender = $row['gender'];
    $tmp_lahir = $row['tmp_lahir'];
    $tgl_lahir = $row['tgl_lahir'];
    $telepon = $row['telepon'];
    $alamat = $row['alamat'];
    $unit_kerja_id = $row['unit_kerja_id'];
    $kategori = $row['kategori'];
}

if (isset($_POST['submit'])) {
    $_nama = $_POST['nama'];
    $_gender = $_POST['gender'];
    $_tmp_lahir = $_POST['tmp_lahir'];
    $_tgl_lahir = $_POST['tgl_lahir'];
    $_telepon = $_POST['telepon'];
    $_alamat = $_POST['alamat'];
    $_unit_kerja_id = $_POST['unit_kerja_id'];
    $_kategori = $_POST['kategori'];

    //Query SQL untuk update data dokter berdasarkan id
    $sql = "UPDATE paramedik SET nama = ?, gender = ?, tmp_lahir = ?, tgl_lahir = ?, telepon = ?, alamat = ?, unit_kerja_id= ?, kategori = ? WHERE id = ?";
    $stmt = $dbh->prepare($sql);
    // Bind parameter
    $stmt->bindParam(1, $_nama);
    $stmt->bindParam(2, $_gender);
    $stmt->bindParam(3, $_tmp_lahir);
    $stmt->bindParam(4, $_tgl_lahir);
    $stmt->bindParam(5, $_telepon);
    $stmt->bindParam(6, $_alamat);
    $stmt->bindParam(7, $_unit_kerja_id);
    $stmt->bindParam(8, $_kategori);
    $stmt->bindParam(9, $id); // Bind id
    // Execute statement SQL
    if ($stmt->execute()) {
        // Setelah pembaruan data berhasil, arahkan pengguna kembali ke halaman yang sesuai
        header('Location: data_dokter.php');
        exit;
    }
}
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    </section>

    <!-- Main content -->
    <section class="content">

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Default box -->
                    <div class="card">
                        <div class="card-header">
                            <h2>Form Dokter Puskesmas</h2>
                        </div>
                        <!-- /.card-header -->
                        <div class= "Container">
                        </div>
                        <div class="card-body">
    <form method="POST" action="" class="m-4">
        <div class="form-group row">
            <label for="nama" class="col-4 col-form-label">Nama Lengkap</label> 
            <div class="col-8">
                <input id="nama" name="nama" type="text" class="form-control" required="required" value="<?= $nama ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="gender" class="col-4 col-form-label">Jenis Kelamin</label>
            <div class="col-8">
                <select id="gender" name="gender" class="custom-select">
                    <option value="L" <?= ($gender == 'L') ? 'selected' : '' ?>>Laki-Laki</option>
                    <option value="P" <?= ($gender == 'P') ? 'selected' : '' ?>>Perempuan</option>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label for="tmp_lahir" class="col-4 col-form-label">Tempat Lahir</label> 
            <div class="col-8">
                <input id="tmp_lahir" name="tmp_lahir" type="text" class="form-control" required="required" value="<?= $tmp_lahir ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="tgl_lahir" class="col-4 col-form-label">Tanggal Lahir</label> 
            <div class="col-8">
                <input id="tgl_lahir" name="tgl_lahir" type="date" class="form-control" required="required" value="<?= $tgl_lahir ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="telepon" class="col-4 col-form-label">Telepon</label> 
            <div class="col-8">
                <input id="telepon" name="telepon" type="tel" class="form-control" required="required" value="<?= $telepon ?>">
            </div>
        </div>
        <div class="form-group row">
            <label for="alamat" class="col-4 col-form-label">Alamat</label> 
            <div class="col-8">
                <textarea id="alamat" name="alamat" cols="40" rows="5" class="form-control" required="required"><?= $alamat ?></textarea>
            </div>
        </div>
        <div class="form-group row">
        <label for="unit_kerja_id" class="col-4 col-form-label">Unit Kerja</label> 
            <div class="col-8">
                <select id="unit_kerja_id" name="unit_kerja_id" class="custom-select">
                    <option value="1" <?= ($unit_kerja_id == '1') ? 'selected' : '' ?>>Unit Gawat Darurat</option>
                    <option value="2" <?= ($unit_kerja_id == '2') ? 'selected' : '' ?>>Unit Pelayanan Rawat Jalan</option>
                    <option value="3" <?= ($unit_kerja_id == '3') ? 'selected' : '' ?>>Unit Kesehatan Ibu dan Anak (KIA)</option>
                    <option value="4" <?= ($unit_kerja_id == '4') ? 'selected' : '' ?>>Unit Pelayanan Kesehatan Masyarakat</option>
                    <option value="5" <?= ($unit_kerja_id == '5') ? 'selected' : '' ?>>Unit Manajemen Program Kesehatan</option>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label for="kategori" class="col-4 col-form-label">Kategori</label> 
            <div class="col-8">
                <select id="kategori" name="kategori" class="custom-select" required="required">
                    <option value="Umum" <?= ($kategori == 'Umum') ? 'selected' : '' ?>>Umum</option>
                    <option value="Spesialis" <?= ($kategori == 'Spesialis') ? 'selected' : '' ?>>Spesialis</option>
                    <option value="Bidan" <?= ($kategori == 'Bidan') ? 'selected' : '' ?>>Bidan</option>
                    <option value="Dokter Gigi" <?= ($kategori == 'Dokter Gigi') ? 'selected' : '' ?>>Dokter Gigi</option>
                    <option value="Anastesi" <?= ($kategori == 'Anastesi') ? 'selected' : '' ?>>Anastesi</option>
                    <option value="Bedah" <?= ($kategori == 'Bedah') ? 'selected' : '' ?>>Bedah</option>
                    <option value="Ginekolog" <?= ($kategori == 'Ginekolog') ? 'selected' : '' ?>>Ginekolog</option>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <div class="offset-4 col-8">
                <button name="submit" type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
    </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>
<?php
require_once 'footer.php';
?>
