<?php
require_once 'dbkoneksi.php'; 
require_once 'header.php';
require_once 'sidebar.php';

// Periksa apakah variabel id ada isinya
if (isset($_GET['id'])) {
    $id_periksa = $_GET['id'];
    // Query untuk mengambil data periksa berdasarkan id
    $sql = "SELECT * FROM periksa WHERE id = ?";
    $stmt = $dbh->prepare($sql);
    $stmt->execute([$id_periksa]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Periksa apakah form telah disubmit
if (isset($_POST['submit'])) {
    // Ambil data dari form
    $tanggal = $_POST['tanggal'];
    $tensi = $_POST['tensi'];
    $keterangan = $_POST['keterangan'];
    $berat = $_POST['berat'];
    $tinggi = $_POST['tinggi'];
    $pasien_id = $_POST['pasien_id'];
    $dokter_id = $_POST['dokter_id'];
    // Query SQL untuk update data periksa berdasarkan id
    $sql = "UPDATE periksa SET tanggal = ?, tensi = ?, keterangan = ?, berat = ?, tinggi = ?, pasien_id = ?, dokter_id = ? WHERE id = ?";
    $stmt = $dbh->prepare($sql);
    // Bind parameter
    $stmt->bindParam(1, $tanggal);
    $stmt->bindParam(2, $tensi);
    $stmt->bindParam(3, $keterangan);
    $stmt->bindParam(4, $berat);
    $stmt->bindParam(5, $tinggi);
    $stmt->bindParam(6, $pasien_id);
    $stmt->bindParam(7, $dokter_id);
    $stmt->bindParam(8, $id_periksa); // Bind id
    // Execute statement SQL
    if ($stmt->execute()) {
        // Setelah pembaruan data berhasil, arahkan pengguna kembali ke halaman yang sesuai
        header('Location: data_periksa.php');
        exit;
    } else {
        echo "Gagal melakukan pembaruan data.";
    }
}
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
    </section>

    <!-- Main content -->
    <section class="content">

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Default box -->
                    <div class="card">
                        <div class="card-header">
                            <h2>Form Periksa</h2>
                        </div>
                        <!-- /.card-header -->
                        <div class= "Container">
                        </div>
                        <div class="card-body">
    <form method="POST" action="" class="m-4">
      <input type="hidden" name="id_periksa" value="<?php echo $id_periksa; ?>">
      <div class="form-group row">
        <label for="tanggal" class="col-4 col-form-label">Tanggal</label> 
        <div class="col-8">
          <input id="tanggal" name="tanggal" type="date" class="form-control" required="required" value="<?php echo $row['tanggal']; ?>">
        </div>
      </div>
      <div class="form-group row">
        <label for="tensi" class="col-4 col-form-label">Tensi Darah</label> 
        <div class="col-8">
          <input id="tensi" name="tensi" type="text" class="form-control" required="required" value="<?php echo $row['tensi']; ?>">
        </div>
      </div>
      <div class="form-group row">
        <label for="keterangan" class="col-4 col-form-label">Keterangan</label> 
        <div class="col-8">
          <textarea id="keterangan" name="keterangan" cols="40" rows="5" class="form-control" required="required"><?php echo $row['keterangan']; ?></textarea>
        </div>
      </div>
      <div class="form-group row">
        <label for="berat" class="col-4 col-form-label">Berat Badan (kg)</label> 
        <div class="col-8">
          <input id="berat" name="berat" type="number" step="0.01" class="form-control" required="required" value="<?php echo $row['berat']; ?>">
        </div>
      </div>
      <div class="form-group row">
        <label for="tinggi" class="col-4 col-form-label">Tinggi Badan (cm)</label> 
        <div class="col-8">
          <input id="tinggi" name="tinggi" type="number" step="0.01" class="form-control" required="required" value="<?php echo $row['tinggi']; ?>">
        </div>
      </div>
      <div class="form-group row">
          <label for="pasien_id" class="col-4 col-form-label">Pasien ID</label>
          <div class="col-8">
              <select id="pasien_id" name="pasien_id" class="custom-select">
                  <?php
                  $sqlpasien = "SELECT * FROM pasien";
                  $rspasien = $dbh->query($sqlpasien);
                  foreach ($rspasien as $rowpasien) {
                      $selected = ($row['pasien_id'] == $rowpasien['id']) ? 'selected' : '';
                      echo "<option value='" . $rowpasien['id'] . "' $selected>" . $rowpasien['nama'] . "</option>";
                  }
                  ?>
              </select>
          </div>
      </div>
      <div class="form-group row">
          <label for="dokter_id" class="col-4 col-form-label">Dokter ID</label>
          <div class="col-8">
              <select id="dokter_id" name="dokter_id" class="custom-select">
                  <?php
                  $sqldokter = "SELECT * FROM paramedik";
                  $rsdokter = $dbh->query($sqldokter);
                  foreach ($rsdokter as $rowdokter) {
                      $selected = ($row['dokter_id'] == $rowdokter['id']) ? 'selected' : '';
                      echo "<option value='" . $rowdokter['id'] . "' $selected>" . $rowdokter['nama'] . "</option>";
                  }
                  ?>
              </select>
          </div>
      </div>
      <div class="form-group row">
        <div class="offset-4 col-8">
          <button name="submit" type="submit" class="btn btn-primary">Submit</button>
        </div>
      </div>
    </form>
    </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>
<?php
require_once 'footer.php';
?>
