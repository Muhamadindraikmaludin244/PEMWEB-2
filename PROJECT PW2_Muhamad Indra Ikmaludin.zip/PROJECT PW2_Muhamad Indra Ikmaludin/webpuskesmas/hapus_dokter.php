<?php
// Sisipkan file koneksi
require_once 'dbkoneksi.php';

// Periksa apakah parameter id dokter sudah diterima
if (isset($_GET['id'])) {
    // Ambil ID dokter dari parameter URL
    $id_dokter = $_GET['id'];

    try {
        // Tampilkan konfirmasi JavaScript sebelum menghapus
        echo '<script>';
        echo 'if(confirm("Apakah anda yakin ingin menghapus data dokter ini ?")){';
        // Query SQL untuk menghapus data dokter berdasarkan ID
        $sql = "DELETE FROM paramedik WHERE id = ?";
        $stmt = $dbh->prepare($sql);
        $stmt->bindParam(1, $id_dokter);
        $stmt->execute();
        // Redirect kembali ke halaman "List data dokter" setelah berhasil menghapus
        echo 'window.location.href = "data_dokter.php";';
        echo '} else {';
        // Jika pengguna memilih untuk membatalkan penghapusan, kembali ke halaman sebelumnya
        echo 'window.history.back();';
        echo '}';
        echo '</script>';
    } catch (PDOException $e) {
        // Tangani kesalahan jika terjadi error dalam proses penghapusan
        echo "Error: " . $e->getMessage();
    }
} else {
    // Jika tidak ada parameter ID dokter yang diterima, kembali ke halaman sebelumnya
    header("Location: data_dokter.php");
    exit();
}
?>
