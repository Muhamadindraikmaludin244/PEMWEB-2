<?php
// Sisipkan file koneksi
require_once 'dbkoneksi.php';

// Periksa apakah parameter id pasien sudah diterima
if (isset($_GET['id'])) {
    // Ambil ID pasien dari parameter URL
    $id_pasien = $_GET['id'];

    try {
        // Tampilkan konfirmasi JavaScript sebelum menghapus
        echo '<script>';
        echo 'if(confirm("Apakah anda yakin ingin menghapus data pasien ini ?")){';
        // Query SQL untuk menghapus data pasien berdasarkan ID
        $sql = "DELETE FROM pasien WHERE id = ?";
        $stmt = $dbh->prepare($sql);
        $stmt->bindParam(1, $id_pasien);
        $stmt->execute();
        // Redirect kembali ke halaman "List data pasien" setelah berhasil menghapus
        echo 'window.location.href = "data_pasien.php";';
        echo '} else {';
        // Jika pengguna memilih untuk membatalkan penghapusan, kembali ke halaman sebelumnya
        echo 'window.history.back();';
        echo '}';
        echo '</script>';
    } catch (PDOException $e) {
        // Tangani kesalahan jika terjadi error dalam proses penghapusan
        echo "Error: " . $e->getMessage();
    }
} else {
    // Jika tidak ada parameter ID pasien yang diterima, kembali ke halaman sebelumnya
    header("Location: data_pasien.php");
    exit();
}
?>
