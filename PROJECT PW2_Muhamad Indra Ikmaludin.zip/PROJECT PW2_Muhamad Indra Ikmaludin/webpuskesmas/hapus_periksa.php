<?php
// Sisipkan file koneksi
require_once 'dbkoneksi.php';

// Periksa apakah parameter id periksa sudah diterima
if (isset($_GET['id'])) {
    // Ambil ID periksa dari parameter URL
    $id_periksa = $_GET['id'];

    try {
        // Tampilkan konfirmasi JavaScript sebelum menghapus
        echo '<script>';
        echo 'if(confirm("Apakah Anda yakin ingin menghapus data periksa ini?")){';
        // Query SQL untuk menghapus data periksa berdasarkan ID
        $sql = "DELETE FROM periksa WHERE id = ?";
        $stmt = $dbh->prepare($sql);
        $stmt->bindParam(1, $id_periksa);
        $stmt->execute();
        // Redirect kembali ke halaman "List data periksa" setelah berhasil menghapus
        echo 'window.location.href = "data_periksa.php";';
        echo '} else {';
        // Jika pengguna memilih untuk membatalkan penghapusan, kembali ke halaman sebelumnya
        echo 'window.history.back();';
        echo '}';
        echo '</script>';
    } catch (PDOException $e) {
        // Tangani kesalahan jika terjadi error dalam proses penghapusan
        echo "Error: " . $e->getMessage();
    }
} else {
    // Jika tidak ada parameter ID periksa yang diterima, kembali ke halaman sebelumnya
    header("Location: data_periksa.php");
    exit();
}
?>
