<?php
// Include database connection
require_once 'dbkoneksi.php';

try {
    // Capture data from form
    $nama = $_POST['nama'];
    $gender = $_POST['gender'];
    $tmp_lahir = $_POST['tmp_lahir']; // Kolom diubah menjadi tmp_lahir sesuai dengan perubahan pada tabel paramedik
    $tgl_lahir = $_POST['tgl_lahir'];
    $telepon = $_POST['telepon'];
    $alamat = $_POST['alamat'];
    $unit_kerja_id = $_POST['unit_kerja_id'];
    $kategori = $_POST['kategori'];

    // Prepare SQL insert query
    $sql = "INSERT INTO paramedik (nama, gender, tmp_lahir, tgl_lahir, telepon, alamat, unit_kerja_id, kategori)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare statement
    $stmt = $dbh->prepare($sql);

    // Bind parameter
    $stmt->bindParam(1, $nama);
    $stmt->bindParam(2, $gender);
    $stmt->bindParam(3, $tmp_lahir);
    $stmt->bindParam(4, $tgl_lahir);
    $stmt->bindParam(5, $telepon);
    $stmt->bindParam(6, $alamat);
    $stmt->bindParam(7, $unit_kerja_id);
    $stmt->bindParam(8, $kategori);

    // Execute statement SQL
    $stmt->execute();

    // Redirect to data_dokter.php
    header('Location: data_dokter.php');
    exit(); // Menghentikan eksekusi
} catch (PDOException $e) {
    // Tangani kesalahan koneksi
    echo 'Error: ' . $e->getMessage();
}
?>
