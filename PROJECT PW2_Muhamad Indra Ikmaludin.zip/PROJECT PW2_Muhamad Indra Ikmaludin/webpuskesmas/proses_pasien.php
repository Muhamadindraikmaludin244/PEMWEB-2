<?php
// Include database connection
require_once 'dbkoneksi.php';

try {
    // Capture data from form
    $kode = $_POST['kode'];
    $nama = $_POST['nama'];
    $tmp_lahir = $_POST['tmp_lahir'];
    $tgl_lahir = $_POST['tgl_lahir'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];
    $kelurahan_id = $_POST['kelurahan_id'];
    // Prepare SQL insert query
    $sql = "INSERT INTO pasien (kode, nama, tmp_lahir, tgl_lahir, gender, email, alamat,kelurahan_id)
            VALUES (?, ?, ?, ?, ?, ?,?,?)";

    // Prepare statement SQL
    $stmt = $dbh->prepare($sql);

    // Bind parameter
    $stmt->bindParam(1, $kode);
    $stmt->bindParam(2, $nama);
    $stmt->bindParam(3, $tmp_lahir);
    $stmt->bindParam(4, $tgl_lahir);
    $stmt->bindParam(5, $gender);
    $stmt->bindParam(6, $email);
    $stmt->bindParam(7, $alamat);
    $stmt->bindParam(8, $kelurahan_id);
    // Execute statement SQL
    $stmt->execute();

    // Redirect to data_pasien.php
    header('Location: data_pasien.php');
    exit(); // Penting untuk menghentikan eksekusi skrip setelah redirect
} catch (PDOException $e) {
    // Tangani kesalahan koneksi
    echo 'Error: ' . $e->getMessage();
}
?>
<!--  -->