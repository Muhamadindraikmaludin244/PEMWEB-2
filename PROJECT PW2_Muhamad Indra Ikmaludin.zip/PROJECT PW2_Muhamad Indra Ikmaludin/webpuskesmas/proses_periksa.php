<?php
// Include database connection
require_once 'dbkoneksi.php';

try {
    // Capture data from form
    $tanggal = $_POST['tanggal'];
    $tensi = $_POST['tensi'];
    $keterangan = $_POST['keterangan'];
    $berat = $_POST['berat'];
    $tinggi = $_POST['tinggi'];
    $pasien_id = $_POST['pasien_id'];
    $dokter_id = $_POST['dokter_id'];

    // Prepare SQL insert query
    $sql = "INSERT INTO periksa (tanggal, tensi, keterangan, berat, tinggi, pasien_id, dokter_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    // Prepare statement
    $stmt = $dbh->prepare($sql);

    // Bind parameter
    $stmt->bindParam(1, $tanggal);
    $stmt->bindParam(2, $tensi);
    $stmt->bindParam(3, $keterangan);
    $stmt->bindParam(4, $berat);
    $stmt->bindParam(5, $tinggi);
    $stmt->bindParam(6, $pasien_id);
    $stmt->bindParam(7, $dokter_id);

    // Execute statement SQL
    $stmt->execute();

    // Redirect to data_periksa.php
    header('Location: data_periksa.php');
    exit(); // Stop further execution
} catch (PDOException $e) {
    // Handle connection error
    echo 'Error: ' . $e->getMessage();
}
?>
