<h1>Selamat Datang di Dashboard</h1>
<?php /**PATH C:\xampp\htdocs\PEMPROGRAMAN WEB 2\app-puskesmas\resources\views/dashboard/index.blade.php ENDPATH**/ ?>