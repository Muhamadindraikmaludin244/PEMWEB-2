<?php
    $nama = "Muhamad Indra Ikmmaludin";
    $nim = "0110123056";
    $prodi = "Sistem Informasi";
    $angkatan = "2023";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>About</title>
</head>
<body>
    <h3>Nama Saya  <?php echo e($nama); ?>, NIM saya <?php echo e($nim); ?>, Program Studi Saya <?php echo e($prodi); ?>, Saya Tahun Angkatan <?php echo e($angkatan); ?></h3>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\PEMPROGRAMAN WEB 2\app-puskesmas\resources\views/about.blade.php ENDPATH**/ ?>